-- Создание базы данных
CREATE DATABASE security_db;

\c security_db;

-- Таблица auth_log
CREATE TABLE auth_log (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address INET,
    success BOOLEAN
);

-- Роль auditor (только чтение)
CREATE ROLE auditor WITH LOGIN PASSWORD 'Auditor2026!';
GRANT CONNECT ON DATABASE security_db TO auditor;
GRANT USAGE ON SCHEMA public TO auditor;
GRANT SELECT ON auth_log TO auditor;

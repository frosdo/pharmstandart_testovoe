#!/bin/bash
DB_NAME="security_db"
BACKUP_FILE="/tmp/${DB_NAME}_$(date +%Y%m%d_%H%M%S).sql"
PASSPHRASE="MyBackup2026!"
sudo -u postgres pg_dump --no-password -U postgres -d $DB_NAME -F p > $BACKUP_FILE
gpg --symmetric --cipher-algo AES256 --batch --passphrase "$PASSPHRASE" $BACKUP_FILE
rm -f $BACKUP_FILE
echo "Резервная копия: ${BACKUP_FILE}.gpg, пароль: $PASSPHRASE"
